<footer class="container-fluid bg-primary py-1 text-white text-center">
    <div class="container d-flex flex-wrap justify-content-between align-items-center py-3 my-4">
        <div class="col-md-6 d-flex align-items-center">
            <p class="mb-3 mb-md-0 text-white">2023 &copy; Polres Mamuju Tengah</p>
        </div>

        <p class="nav col-md-6 justify-content-end list-unstyled d-flex text-start text-md-end">
            Sistem Informasi Manajemen Pengaduan Tindak Pidana (SIMPANAN)
        </p>
    </div>
</footer>