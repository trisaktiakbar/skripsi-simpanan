window.addEventListener("DOMContentLoaded", (event) => {
  const datatablesSimple = document.getElementById("datatablesSimple");
  if (datatablesSimple) {
    new simpleDatatables.DataTable(datatablesSimple);
  }
});

window.addEventListener("DOMContentLoaded", (event) => {
  const datatablesSimple = document.getElementById("datatablesSimple2");
  if (datatablesSimple) {
    new simpleDatatables.DataTable(datatablesSimple);
  }
});

window.addEventListener("DOMContentLoaded", (event) => {
  const datatablesSimple = document.getElementById("datatablesSimple3");
  if (datatablesSimple) {
    new simpleDatatables.DataTable(datatablesSimple);
  }
});

window.addEventListener("DOMContentLoaded", (event) => {
  const datatablesSimple = document.getElementById("datatablesSimple4");
  if (datatablesSimple) {
    new simpleDatatables.DataTable(datatablesSimple);
  }
});
