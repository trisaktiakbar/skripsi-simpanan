<footer class="py-4 bg-light mt-auto" id="footer">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted" id="footer-copyright">2022 &copy; Polres Mamuju Tengah</div>
            <div>
                <p class="mb-0 pb-0 text-muted" id="footer-text">Sistem Informasi Manajemen Pengaduan Tindak Pidana dan Pelanggaran (SIMPANAN)</p>
            </div>
        </div>
    </div>
</footer>