<?php

$presence_id = "ucp22bzm566RdIIP0Qr1";
$presence_key = "A1YuE3XOWuB4xRjiNnkj";
