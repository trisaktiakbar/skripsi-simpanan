<?php
$DOMAIN_NAME = "http://localhost/simpanan";
